
<script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
