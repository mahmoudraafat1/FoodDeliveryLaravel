
    <link rel="stylesheet" href="{{ asset('assets/css/jquery.dataTables.min.css')}}">
